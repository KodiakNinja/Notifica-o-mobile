# Running end-to-end tests

Then end-to-end tests depend on ChromeDriver, the web driver for Chrome.  [You can install it here](http://chromedriver.chromium.org/downloads).  Install a version that matches the version of Chrome on your machine.

After that, you can run the end-to-end tests with

```bash
npm run test:e2e
```

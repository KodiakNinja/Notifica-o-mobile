module.exports = {
  automock: false,
  setupFiles: ['./test-setup.js'],
  testEnvironment: 'jsdom'
};

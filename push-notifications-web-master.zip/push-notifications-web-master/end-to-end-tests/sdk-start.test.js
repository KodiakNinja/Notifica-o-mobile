import {
  launchServer,
  createChromeWebDriver,
  NOTIFICATIONS_GRANTED,
  unregisterServiceWorker,
  SCRIPT_TIMEOUT_MS
} from './test-utils';

let killServer = null;
let chromeDriver = null;

beforeAll(() => {
  return launchServer()
    .then(killFunc => {
      killServer = killFunc;
    })
    .then(() => createChromeWebDriver(NOTIFICATIONS_GRANTED))
    .then(driver => {
      chromeDriver = driver;
    });
});

afterEach(() => unregisterServiceWorker(chromeDriver));

test('SDK should register a device with errol', async () => {
  await chromeDriver.get('http://localhost:3000');
  await chromeDriver.wait(() => {
    return chromeDriver.getTitle().then(title => {
      return title.includes('Test Page');
    });
  }, 2000);

  const initialDeviceId = await chromeDriver.executeAsyncScript(() => {
    const asyncScriptReturnCallback = arguments[arguments.length - 1];
    const instanceId = 'deadc0de-2ce6-46e3-ad9a-5c02d0ab119b';
    const beamsClient = new PusherPushNotifications.Client({ instanceId });
    beamsClient
      .start()
      .then(() => beamsClient.getDeviceId())
      .then(deviceId => {
        asyncScriptReturnCallback(deviceId);
      })
      .catch(e => {
        asyncScriptReturnCallback(e.message);
      });
  });

  expect(initialDeviceId).toContain('web-');
}, SCRIPT_TIMEOUT_MS);

test('SDK should remember the device ID', async () => {
  await chromeDriver.get('http://localhost:3000');
  await chromeDriver.wait(() => {
    return chromeDriver.getTitle().then(title => title.includes('Test Page'));
  }, 2000);

  const initialDeviceId = await chromeDriver.executeAsyncScript(() => {
    const asyncScriptReturnCallback = arguments[arguments.length - 1];

    const instanceId = 'deadc0de-2ce6-46e3-ad9a-5c02d0ab119b';
    const beamsClient = new PusherPushNotifications.Client({ instanceId });
    beamsClient
      .start()
      .then(() => beamsClient.getDeviceId())
      .then(deviceId => asyncScriptReturnCallback(deviceId))
      .catch(e => asyncScriptReturnCallback(e.message));
  });

  await chromeDriver.get('http://localhost:3000');
  await chromeDriver.wait(() => {
    return chromeDriver.getTitle().then(title => title.includes('Test Page'));
  }, 2000);

  const reloadedDeviceId = await chromeDriver.executeAsyncScript(() => {
    const asyncScriptReturnCallback = arguments[arguments.length - 1];

    const instanceId = 'deadc0de-2ce6-46e3-ad9a-5c02d0ab119b';
    const beamsClient = new PusherPushNotifications.Client({ instanceId });
    beamsClient
      .start()
      .then(() => beamsClient.getDeviceId())
      .then(deviceId => asyncScriptReturnCallback(deviceId))
      .catch(e => asyncScriptReturnCallback(e.message));
  });

  expect(reloadedDeviceId).toBe(initialDeviceId);
});

describe('When service worker is missing', () => {
  // Need a new test server that is configured to return 404 when asked
  // for the service worker
  let killTestServer;
  beforeAll(() => {
    return launchServer({
      port: 3210,
      serviceWorkerPresent: false,
    }).then(killFunc => {
      killTestServer = killFunc;
    });
  });

  test('SDK should return the proper exception if service worker cannot be found', async () => {
    await chromeDriver.get('http://localhost:3210');
    await chromeDriver.wait(() => {
      return chromeDriver.getTitle().then(title => title.includes('Test Page'));
    }, 2000);

    // make sure device isn't there
    await chromeDriver.executeAsyncScript(() => {
      const asyncScriptReturnCallback = arguments[arguments.length - 1];

      let deleteDbRequest = window.indexedDB.deleteDatabase(
        'beams-deadc0de-2ce6-46e3-ad9a-5c02d0ab119b'
      );
      deleteDbRequest.onsuccess = asyncScriptReturnCallback;
      deleteDbRequest.onerror = asyncScriptReturnCallback;
    });

    const startResult = await chromeDriver.executeAsyncScript(async () => {
      const asyncScriptReturnCallback = arguments[arguments.length - 1];

      const instanceId = 'deadc0de-2ce6-46e3-ad9a-5c02d0ab119b';
      const beamsClient = new PusherPushNotifications.Client({
        instanceId,
      });
      beamsClient
        .start()
        .then(() => asyncScriptReturnCallback('start succeeded'))
        .catch(e => asyncScriptReturnCallback(e.message));
    });

    expect(startResult).not.toContain('succeeded');
    expect(startResult).toContain('service worker missing');
  });

  afterAll(() => {
    killTestServer();
  });
});

test('SDK should register a device with errol without registering the service worker itself', async () => {
  // this is the case where customers want to manage the service worker themselves
  await chromeDriver.get('http://localhost:3000');
  await chromeDriver.wait(() => {
    return chromeDriver.getTitle().then(title => title.includes('Test Page'));
  }, 2000);

  // make sure device isn't there
  await chromeDriver.executeAsyncScript(() => {
    const asyncScriptReturnCallback = arguments[arguments.length - 1];

    let deleteDbRequest = window.indexedDB.deleteDatabase(
      'beams-deadc0de-2ce6-46e3-ad9a-5c02d0ab119b'
    );
    deleteDbRequest.onsuccess = asyncScriptReturnCallback;
    deleteDbRequest.onerror = asyncScriptReturnCallback;
  });
  const initialDeviceId = await chromeDriver.executeAsyncScript(async () => {
    const asyncScriptReturnCallback = arguments[arguments.length - 1];

    const instanceId = 'deadc0de-2ce6-46e3-ad9a-5c02d0ab119b';
    const beamsClient = new PusherPushNotifications.Client({
      serviceWorkerRegistration: await window.navigator.serviceWorker.register(
        '/service-worker.js'
      ),
      instanceId,
    });
    beamsClient
      .start()
      .then(() => beamsClient.getDeviceId())
      .then(deviceId => asyncScriptReturnCallback(deviceId))
      .catch(e => asyncScriptReturnCallback(e.message));
  });

  expect(initialDeviceId).toContain('web-');
});

test('SDK should fail if provided service worker is in wrong scope', async () => {
  await chromeDriver.get('http://localhost:3000');
  await chromeDriver.wait(() => {
    return chromeDriver.getTitle().then(title => title.includes('Test Page'));
  }, 2000);

  const errorMessage = await chromeDriver.executeAsyncScript(() => {
    const asyncScriptReturnCallback = arguments[arguments.length - 1];

    const instanceId = 'deadc0de-2ce6-46e3-ad9a-5c02d0ab119b';
    return window.navigator.serviceWorker
      .register('/not-the-root/service-worker.js')
      .then(registration => {
        const beamsClient = new PusherPushNotifications.Client({
          instanceId,
          serviceWorkerRegistration: registration,
        });
        return beamsClient.start();
      })
      .catch(e => asyncScriptReturnCallback(e.message));
  });

  expect(errorMessage).toContain(
    'current page not in serviceWorkerRegistration scope'
  );
});

afterAll(() => {
  if (killServer) {
    killServer();
  }
  if (chromeDriver) {
    chromeDriver.quit();
  }
});

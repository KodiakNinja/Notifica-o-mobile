global.fetch = require('jest-fetch-mock');
